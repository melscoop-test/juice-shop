beforeEach(() => {
  cy.setCookie("cookieconsent_status", "dismiss");
  cy.setCookie("welcomebanner_status", "dismiss");
});
